let config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    backgroundColor: '#1d1d1d',
    physics: {
        default: 'arcade',
        arcade: { gravity: { y: 0 } }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

let player, cursors, meteors, score = 0, scoreText;

let game = new Phaser.Game(config);

function preload() {
    this.load.image('player', 'https://examples.phaser.io/assets/sprites/ship.png');
    this.load.image('meteor', 'https://examples.phaser.io/assets/sprites/asteroid.png');
}

function create() {
    player = this.physics.add.image(400, 550, 'player').setCollideWorldBounds(true);
    cursors = this.input.keyboard.createCursorKeys();
    meteors = this.physics.add.group();
    scoreText = this.add.text(10, 10, 'Score: 0', { fontSize: '20px', fill: '#fff' });

    this.time.addEvent({
        delay: 1000,
        callback: () => {
            let x = Phaser.Math.Between(0, 800);
            let meteor = meteors.create(x, 0, 'meteor');
            meteor.setVelocityY(Phaser.Math.Between(100, 200));
        },
        callbackScope: this,
        loop: true
    });

    this.physics.add.overlap(player, meteors, hitMeteor, null, this);
}

function update() {
    if (cursors.left.isDown) {
        player.setVelocityX(-300);
    } else if (cursors.right.isDown) {
        player.setVelocityX(300);
    } else {
        player.setVelocityX(0);
    }

    score += 1;
    scoreText.setText('Score: ' + Math.floor(score / 10));
}

function hitMeteor(player, meteor) {
    this.physics.pause();
    player.setTint(0xff0000);
}
